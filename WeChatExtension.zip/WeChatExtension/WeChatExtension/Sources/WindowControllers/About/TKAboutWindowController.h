//
//  TKAboutWindowController.h
//  WeChatExtension
//
//  Created by WeChatExtension on 2018/5/4.
//  Copyright © 2018年 WeChatExtension. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TKAboutWindowController : NSWindowController

@end
