//
//  TKRemoteControlCell.h
//  WeChatExtension
//
//  Created by WeChatExtension on 2019/8/8.
//  Copyright © 2019年 WeChatExtension. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TKRemoteControlCell : NSView

- (void)setupWithData:(id)data;

@end
