//
//  NSMenu+Action.h
//  WeChatExtension
//
//  Created by WeChatExtension on 2018/4/15.
//  Copyright © 2018年 WeChatExtension. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSMenu (Action)

- (void)addItems:(NSArray *)subItems;

@end
